package com.example.studentcrud.model;
import javax.persistence.*;
@Entity
@Table(name="employees")

public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long id;
	@Column(name="first_Name")
	private String first_Name;
	@Column(name="last_Name")
	private String last_Name;
	@Column(name="email")
	private String email;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getFirstName() {
		return first_Name;
	}
	public void setFirstName(String firstName) {
		this.first_Name = firstName;
	}
	public String getLastName() {
		return last_Name;
	}
	public void setLastName(String lastName) {
		this.last_Name = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	

}
